//
//  ContactViewController.h
//  Scenarios
//
//  Created by Adam Burstein on 6/22/18.
//  Copyright © 2018 Adam Burstein. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactViewController : UITableViewController

@property (nonatomic, strong) NSDictionary *contactDictionary;

@end
