//
//  QuestionViewController.h
//  Scenarios
//
//  Created by Adam Burstein on 2/2/18.
//  Copyright © 2018 Adam Burstein. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionViewController : UITableViewController

@property (nonatomic, strong) NSDictionary *dataDictionary;

@end
